Kropla — Firewisp Studio

EN: Drink more water without thinking about it.
One tap logs a glass. Kropla works out your daily goal from your weight and height, shows progress on a home-screen widget and nudges you when you forget. Nothing leaves your phone: no account, no cloud, no analytics.

PL: Pij więcej wody, nie myśląc o tym.
Jedno dotknięcie to jedna szklanka. Kropla liczy cel dzienny z Twojej wagi i wzrostu, pokazuje postęp na widżecie i przypomina, gdy zapomnisz. Nic nie wychodzi poza telefon: bez konta, bez chmury, bez analityki.

Page: https://firewispstudio.com/kropla/
Contact: tomasz.matusiak@post.pl
