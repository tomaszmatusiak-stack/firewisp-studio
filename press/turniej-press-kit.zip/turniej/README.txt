Turniej — Firewisp Studio

EN: Type the players, pick round-robin or knockout, draw the pairs. The table keeps itself.
Made for football evenings on the console or the table-football league at work: every player against every player, or a knockout bracket with byes. Enter results, the standings and the next matches update themselves, and a stopwatch is built in. Everything stays on the device.

PL: Wpisz graczy, wybierz tryb, wylosuj pary. Tabela liczy się sama.
Dla wieczorów z piłką na konsoli albo ligi piłkarzyków w pracy: każdy z każdym albo puchar z drabinką i wolnymi losami. Wpisujesz wyniki, tabela i kolejne mecze liczą się same, stoper jest wbudowany. Wszystko zostaje na urządzeniu.

Page: https://tomaszmatusiak-stack.github.io/firewisp-studio/turniej/
Contact: tomasz.matusiak@post.pl
