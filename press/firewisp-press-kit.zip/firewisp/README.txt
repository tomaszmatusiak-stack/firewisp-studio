Firewisp — Firewisp Studio

EN: Tell Iskra what you want to achieve. She turns it into a route and keeps your streak alive.
Iskra is a small flame and your companion in the app. You describe a goal in your own words, she asks a few questions and lays it out as weeks, milestones and concrete tasks for the next days. Finished steps light up, streaks keep you honest, and when you slip she adjusts instead of nagging. Goals, not forms.

PL: Powiedz Iskrze, co chcesz osiągnąć. Rozpisze to na trasę i przypilnuje serii.
Iskra to mały płomyk i Twoja towarzyszka w apce. Opisujesz cel własnymi słowami, ona dopytuje i układa go w tygodnie, kamienie milowe i konkretne zadania na najbliższe dni. Skończone kroki się zapalają, serie trzymają w ryzach, a gdy coś się posypie, Iskra przekłada plan zamiast marudzić. Cele, nie formularze.

Page: https://tomaszmatusiak-stack.github.io/firewisp-studio/firewisp/
Contact: tomasz.matusiak@post.pl
