Bog Night — Firewisp Studio

EN: Keep the hut standing until sunrise.
Creatures from Polish folklore — strzyga, utopiec, will-o'-the-wisps, a werewolf — walk the boardwalks toward your hut every night. You hold them off with torches, salt, a rowan bow and, when it gets bad, a powder keg. Three worlds, 36 nights, bosses that change form halfway through. A landscape game: best on a laptop or with the phone turned sideways.

PL: Dotrwaj z chatą do świtu.
Co noc po kładkach idą w stronę chaty stwory z polskich bagien: strzygi, utopce, ogniki, wilkołak. Odganiasz je pochodnią, solą, jarzębinowym łukiem, a jak jest źle, beczułką prochu. Trzy światy, 36 nocy, bossowie, którzy w połowie walki zmieniają postać. Gra pozioma: najlepiej na laptopie albo z telefonem obróconym bokiem.

Page: https://tomaszmatusiak-stack.github.io/firewisp-studio/bog-night/
Contact: tomasz.matusiak@post.pl
