Tare – Weight Tracker — Firewisp Studio

EN: One entry a day, a trend you can trust, nothing leaves your phone.
Tare is a private weight log. Enter today's weight in two taps and read the 7-day trend instead of the daily noise of a bathroom scale. Track waist and other measurements, see your BMI with the WHO classification and its source one tap away, set a goal and get a projected date. Fully offline: no account, no ads, no analytics, no in-app purchases. Your backup is a file you own.

PL: Jeden pomiar dziennie, trend, któremu ufasz, nic nie wychodzi poza telefon.
Tare to prywatny dziennik wagi. Wpisujesz dzisiejszą wagę dwoma dotknięciami i czytasz trend 7-dniowy zamiast dziennego szumu z wagi łazienkowej. Mierzysz talię i inne obwody, widzisz BMI z klasyfikacją WHO i źródłem pod ręką, ustawiasz cel i dostajesz prognozowaną datę. W całości offline: bez konta, reklam, analityki i zakupów. Kopia zapasowa to plik, który należy do Ciebie.

Page: https://firewispstudio.com/tare/
Contact: tomasz.matusiak@post.pl
