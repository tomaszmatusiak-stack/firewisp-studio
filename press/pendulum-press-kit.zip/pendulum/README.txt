Pendulum: Rope Swing — Firewisp Studio

EN: Hold to grab the rope, let go to fly. Timing is everything.
A one-thumb momentum game: your release timing is graded EARLY, PERFECT or LATE, and momentum carries between swings. A hundred hand-made levels in ten painted worlds, hidden crystals on riskier routes, and one daily run that everyone plays the same day. Free to start, one purchase for the rest, no ads.

PL: Przytrzymaj, żeby złapać linę, puść, żeby polecieć. Liczy się moment.
Gra na jeden kciuk: moment puszczenia liny jest oceniany jako EARLY, PERFECT albo LATE, a rozpęd przechodzi między hustawkami. Sto ręcznie zrobionych poziomów w dziesięciu malowanych światach, ukryte kryształy na trudniejszych trasach i jeden dzienny poziom, ten sam dla wszystkich. Start za darmo, jeden zakup za resztę, bez reklam.

Page: https://firewispstudio.com/pendulum/
Contact: tomasz.matusiak@post.pl
