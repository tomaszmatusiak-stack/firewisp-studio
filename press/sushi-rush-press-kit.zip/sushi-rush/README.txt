Sushi Rush: Merge Kitchen — Firewisp Studio

EN: Merge dishes, keep hungry customers happy and open sushi bars across Japan.
Drag two matching dishes together to make a better one, serve customers before they lose patience, and spend what you earn on new restaurants from Tokyo to Osaka. 76 levels in three worlds, combos and boosters. No ads, no energy timers. In the browser your progress is saved on your device.

PL: Łącz dania, karm głodnych klientów i otwieraj kolejne bary sushi w Japonii.
Przeciągasz dwa takie same dania, żeby zrobić lepsze, podajesz je, zanim klientom skończy się cierpliwość, a za zarobione monety otwierasz kolejne lokale od Tokio po Osakę. 76 poziomów w trzech światach, combo i boostery. Bez reklam, bez liczników energii. W przeglądarce postęp zapisuje się na Twoim urządzeniu.

Page: https://tomaszmatusiak-stack.github.io/firewisp-studio/sushi-rush/
Contact: tomasz.matusiak@post.pl
