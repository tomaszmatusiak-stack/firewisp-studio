Whirlpick — Firewisp Studio

EN: Can't decide? Add your options, spin the wheel and let chance choose for you.
Who does the dishes, what's for dinner, who goes first. Type options or paste a whole list, spin by button or by flick, and watch the wheel stop. Elimination mode removes the winner so you can draw an order without repeats. No account, no ads, no internet needed.

PL: Nie możesz się zdecydować? Wpisz opcje, zakręć kołem i niech los wybierze.
Kto zmywa, co na obiad, kto zaczyna. Wpisujesz opcje albo wklejasz całą listę, kręcisz przyciskiem lub gestem i patrzysz, gdzie stanie koło. Tryb eliminacji usuwa wylosowane pole, więc losujesz kolejność bez powtórek. Bez konta, bez reklam, bez internetu.

Page: https://tomaszmatusiak-stack.github.io/firewisp-studio/whirlpick/
Contact: tomasz.matusiak@post.pl
